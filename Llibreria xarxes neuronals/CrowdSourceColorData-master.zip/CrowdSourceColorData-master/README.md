# CrowdSourceColorData
For crowd sourcing color data for a machine learning classification example.

Submit data: https://codingtrain.github.io/CrowdSourceColorData/

Loading icon created at [https://loading.io/](https://loading.io/).
